# scSLIDE-py

`scslide-py` (`v0.3.3`) is an independent native Python implementation of sample-level single-cell representations, weighted nearest-neighbor landmark contingency (`LMC`), diffusion trajectories, and R-compatible descriptive differential expression (`F01`–`F19`), with optional `AnnData` (`.h5ad` / `.zarr`) and approximate-neighbor extras.

`scslide-py` is **not** an official Satija Lab package (see [`NOTICE`](NOTICE) and [`LICENSE`](LICENSE)). Public registry upload (PyPI / TestPyPI / GitHub Release / Zenodo) has **not** been performed and requires separate maintainer authorization; install from an audited release wheel/sdist or source checkout as shown below.

## Scope & Scientific Boundaries

- **Stable Core ([`docs/RELEASE_SCOPE.md`](docs/RELEASE_SCOPE.md))**: Native Python counterpart of the 19 R `scSLIDE` (`v0.1.1`) / `Seurat` (`v6.0.0`) sample-level capabilities without `Rscript` or `rpy2` runtime dependencies: grouped/leverage sketching, `QuickCorTest`, `plsr`/`cppls`/`spls` + non-pickle `.npz` model persistence and named-feature query projection, `FindsmNN`/`FindmmNN` (`nn_method='exact'` default; optional `'annoy'` via `[annoy]`), 1-based landmark neighbor aggregation with complete landmark query self-exclusion, Chi-squared Pearson residuals (`Seurat::subset` pre-filter retention + `ScaleData` `+10.0` upper clip), `destiny`-equivalent Diffusion Maps, `princurve`-equivalent Principal Curves, control-referenced `ComBat`/`CellANOVA`, `LandmarkObject`/UMAP (`umap_backend='native'` or `'umap-learn'`), publication plots with `.csv` source-data sidecars, and R-compatible `glmGamPoi` descriptive `traj_de_test`.
- **R-to-Python Migration ([`docs/R_TO_PY_MIGRATION.md`](docs/R_TO_PY_MIGRATION.md))**: Semantic workflow replacement, not an unmodified `.R` script runner or implicit `.rds` reader. Use `examples/export_seurat_for_scslide_py.R` once to export existing R Seurat objects into portable MatrixMarket/CSV files with ID checks.
- **Experimental Inference Isolation ([`docs/scientific_usage_and_migration.md`](docs/scientific_usage_and_migration.md))**: R-compatible `traj_de_test` (`de_inference_mode="descriptive_r_compat"`) produces descriptive post-selection rankings. Out-of-fold (`OOF`) count-splitting, phenotype shuffling, and trajectory-residual permutation (`run_confirmatory_oof_traj_de`, `traj_de_permutation_test`, `run_unified_permutation_inference`) are **exploratory diagnostics** (`confirmatory_calibration_established=False`) and do **not** guarantee general post-selection gene-level FDR or strong FWER control under shared donor latent structure.
- **Empirical Caveats**: Retrospective compatibility on fixed COVID-19 blood (40 draws / 36 subjects) and SEA-AD Microglia-PVM (89 total / 76 filtered / 75 DE / 74 QC donors) cohorts does not establish prospective clinical equivalence, absence of QC/PMI/cell-count confounding, or universal superiority over composition (`CLR`), pseudobulk, or smooth kernel (`scLKME`) representations.
- **Workers & Backends ([`docs/SUPPORTED_ENVIRONMENTS.md`](docs/SUPPORTED_ENVIRONMENTS.md))**: Neighbor APIs default to `n_jobs=1`, resolve negative `n_jobs` against OS CPU affinity and visible conventional Linux cgroup v1/v2 limits, and pass resolved workers to parallel `cKDTree.query` (tree construction is serial), `AnnoyIndex.build` (queries are serial), or `PyNNDescent`. Worker metadata describes configured backend concurrency, not measured active CPUs. Native BLAS/OpenMP and `numba` thread pools require separate environment configuration (`OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `MKL_NUM_THREADS`).

The current recommended exact candidate, SHA256 values, installation receipt, and inherited evidence limits are recorded in the [post-campaign verification supplement](campaign/final-release-acceptance/results/runs/2026-11-17/scslide-py-archive-verification-20261117/README.md). Earlier v0.3.3 builds remain historical artifacts; a version string alone does not identify the audited bytes. No benchmark speedup is promised for the repaired candidate.

## Installation (From Audited Wheel, SDist, or Source Checkout)

Verify the SHA256 digest when installing a release-candidate wheel (or install from a local checkout; build backend requires `setuptools>=77.0.3` for `PEP 639` license metadata):

```bash
# 1. Core install (NumPy/pandas/SciPy/scikit-learn/matplotlib; no AnnData/UMAP extras)
python -m pip install scslide_py-0.3.3-py3-none-any.whl

# 2. Recommended AnnData workflow (exact cKDTree kNN + built-in native UMAP)
python -m pip install "scslide_py-0.3.3-py3-none-any.whl[anndata]"

# 3. Optional umap-learn / PyNNDescent ([ann]) and optional Annoy ([annoy], separate extra)
python -m pip install "scslide_py-0.3.3-py3-none-any.whl[anndata,ann,annoy]"

# Or from a source checkout:
python -m pip install ".[anndata]"
```

Verified on Linux `x86_64` with CPython `3.10`, `3.11`, and `3.12` (pinned reference sets in `constraints/`).

## Portable Quickstart (Descriptive R-Compatible Workflow)

The snippet below runs offline in any clean environment with `scslide-py[anndata]` using the built-in synthetic demonstration fixture (`synthetic_demo_only=True`):

```python
import scslide as sl

# 1. Build portable synthetic cohort (12 subjects, 14 longitudinal draws; synthetic demo only)
adata = sl.build_synthetic_cohort_fixture(seed=20261116)
assert adata.uns["scslide_demo"]["synthetic_demo_only"] is True

# 2. Audit sample-to-subject mapping before sample-level modeling
subj_map = sl.resolve_subject_mapping(
    adata.obs,
    sample_col="Donor",
    subject_id_sep="-",
    invariant_cols=["Age", "Sex"],
    time_col="TimeSinceOnset",
)

# 3. Run end-to-end sample trajectory + R-compatible descriptive DE (default stable mode)
wf = sl.run_scslide_workflow(
    adata,
    sample_col="Donor",
    subject_id_sep="-",
    response_col="Disease",
    celltype_col="cell_type",
    embedding_key="X_pca",
    dims_embedding=range(8),
    ncells_per_group=20,
    ncells_landmark=40,
    knn_range=40,
    ncomp_pls=4,
    nn_method="exact",
    n_jobs=1,
    de_celltype="CD14_Mono",
    de_covariates=("Age", "Sex", "log_count"),
    de_inference_mode="descriptive_r_compat",
)
print(wf.de_results["CD14_Mono"].head(3)[["gene_ID", "beta_Traj", "p_Traj", "adj_pval"]])
```

For a complete file-producing workflow covering `.h5ad`/`.zarr` sample persistence, `.npz` `PLSModel` save/reload, named-feature query projection, and publication plots with `.csv` sidecars, run [`examples/r_to_python_migration_quickstart.py`](examples/r_to_python_migration_quickstart.py).

## Documentation & Maintenance Navigation

- Release Scope & Experimental Boundaries: [`docs/RELEASE_SCOPE.md`](docs/RELEASE_SCOPE.md)
- Supported Environments, Extras & Constraints: [`docs/SUPPORTED_ENVIRONMENTS.md`](docs/SUPPORTED_ENVIRONMENTS.md)
- R (`Seurat` / `scSLIDE`) to Python Migration Guide: [`docs/R_TO_PY_MIGRATION.md`](docs/R_TO_PY_MIGRATION.md)
- Executable Tutorial: [`docs/tutorial.md`](docs/tutorial.md)
- 19-Capability Algorithm Map (`F01`–`F19`): [`docs/algorithm.md`](docs/algorithm.md)
- Inference Modes & Resource Semantics: [`docs/scientific_usage_and_migration.md`](docs/scientific_usage_and_migration.md)
- Maintenance, Redacted Bug Reports & `v0.3.2` Rollback: [`docs/MAINTENANCE_AND_ROLLBACK.md`](docs/MAINTENANCE_AND_ROLLBACK.md)
- Changelog, Attribution & Citation: [`CHANGELOG.md`](CHANGELOG.md), [`NOTICE`](NOTICE), [`CITATION.cff`](CITATION.cff)
- Repository Baseline & Campaign Records (in Git checkout): `FROZEN_BASELINE.md`, `baselines/CURRENT.json`, and `campaign/README.md`
