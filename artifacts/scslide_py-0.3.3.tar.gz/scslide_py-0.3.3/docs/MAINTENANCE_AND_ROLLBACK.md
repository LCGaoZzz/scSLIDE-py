# Maintenance, Rollback, Issue Redaction & Authorized Release Runbook (`v0.3.3`)

## 1. Maintenance Scope & Stability Policy

- **Stable Core (`F01`–`F19` descriptive workflows, `PLSModel` schema `scslide-pls-model-2`, `SampleLevelObject` AnnData schema `sample-level-2`)**:
  - Backwards-compatible bug fixes and dependency compatibility updates within `0.3.x` preserve numerical contracts (47 dual-R stored checks + 6 negative controls) and serialization schemas.
  - Breaking changes to serialized schemas or default statistical semantics require a minor/major version bump and explicit migration notes in [`../CHANGELOG.md`](../CHANGELOG.md).
- **Deprecation Policy for Legacy `confirmatory_*` Aliases**:
  - In `v0.3.3`, `run_confirmatory_oof_traj_de`, column `emp_p_maxf_fwer`, and `run_scslide_workflow` modes `confirmatory_residual_perm`, `confirmatory_oof_countsplit`, and `confirmatory_oof_phenotype_perm` remain available as compatibility aliases, emit `UserWarning`s on workflow alias calls, and tag outputs as `exploratory_*` (`confirmatory_calibration_established=False`).
  - Callers should migrate to `exploratory_insample_residual_perm`, `exploratory_oof_countsplit`, `exploratory_oof_phenotype_perm`, or standard descriptive `descriptive_r_compat`. Legacy `confirmatory_*` mode aliases are scheduled for removal no earlier than `v0.5.0`.
- **Unsupported / Out-of-Scope Combinations**:
  - Issues specific to unverified platforms (Windows/macOS), Python `<3.10` or `>=3.13`, custom container cgroup mounts, or novel post-selection confirmatory theory are triaged as scope requests rather than regressions of the verified Linux `3.10`–`3.12` descriptive core.

## 2. Rollback Anchor (`v0.3.2` Immutable Baseline)

If a deployment encounters an environment or integration regression on `v0.3.3`, roll back immediately to the frozen, hash-locked `v0.3.2` artifact (`scslide-py-0.3.2-1219e90833d6`):

| Object | Frozen `v0.3.2` Identity |
|---|---|
| Navigation branch / snapshot | `freeze/v0.3.2-1219e90833d6` (`a026315e189f719de737e64587f27d6697be6152`) |
| Package source commit / tree | `5ef90abc56cfd6ecaf6afd5eab826c6656c924f6` / `32f0716f34dde00cb1bef58177da4cb4dcc51788` |
| Wheel (`123,417` bytes) SHA256 | `1219e90833d610b707afe8f740c1b5666e0c1eb07d374f920fc89a4d01297dcf` |
| SDist (`132,514` bytes) SHA256 | `67bd16129dc9e49551c236ba3c6eb69fa31208b56e2a71c0d1807e066665a4eb` |

Rollback procedure in a clean virtual environment:
```bash
echo "1219e90833d610b707afe8f740c1b5666e0c1eb07d374f920fc89a4d01297dcf  scslide_py-0.3.2-py3-none-any.whl" | sha256sum -c -
python -m pip install --force-reinstall scslide_py-0.3.2-py3-none-any.whl
python -m pip check
python -I -c "import importlib.metadata as m, scslide; print(m.version('scslide-py'), scslide.__file__)"
```
Never overwrite archived wheels, move `freeze/*` branches, or force-push historical tags.

## 3. Redacted Bug Reporting Checklist

When opening an issue on GitHub (`.github/ISSUE_TEMPLATE/bug_report.md`):
1. **Redact sensitive data**: Never paste patient/donor identifiers, clinical metadata, hospital/internal cluster paths, environment tokens, or restricted `.h5ad`/`.rds` count matrices.
2. **Reproduce synthetically**: Reproduce the error using `scslide.build_synthetic_cohort_fixture()` whenever possible.
3. **Include exact artifact identity**: Report `python -VV`, `importlib.metadata.version("scslide-py")`, wheel/sdist SHA256 (if installed from local artifact), `pip list`, and `scslide.resolve_effective_workers(-1)` output.

## 4. Controlled Post-Authorization Distribution Runbook (Not Executed Automatically)

Public upload to PyPI/TestPyPI, GitHub Release/tag creation, Zenodo/DOI archiving, and changing repository visibility from `PRIVATE` to `PUBLIC` require **explicit, separate maintainer authorization**:

1. **Distribute only the audited archive set (`wheel` + `sdist`)**: Do not make the entire research repository public without first separating or redacting historical campaign directories.
2. **Promote exact verified bytes — never rebuild during publish**:
   - Download the exact accepted `scslide_py-0.3.3-py3-none-any.whl` and `scslide_py-0.3.3.tar.gz` artifacts;
   - Verify `sha256sum -c SHA256SUMS` against `FINAL_CANDIDATE.json`;
   - Run `twine check --strict` and an offline wheelhouse smoke install (`pip install --no-index --find-links ...`);
   - Only after human approval in a protected release environment (e.g., PyPI Trusted Publishing / OIDC with manual environment review), upload those exact verified files. No CI workflow in this repository has publish credentials or automatic upload triggers.
