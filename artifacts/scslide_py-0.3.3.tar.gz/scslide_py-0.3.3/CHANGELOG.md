# Changelog

All notable engineering, packaging, and scope-boundary changes to `scslide-py` are documented in this file.

## [0.3.3] - 2026-11-16 (Release Candidate Closure)

### Fixed
- **Build backend lower bound (`PEP 639`, `C01`)**: Raised `[build-system] requires` from `setuptools>=68` to `setuptools>=77.0.3` so `license = "MIT"` and `license-files = ["LICENSE", "NOTICE"]` match supported `setuptools` versions; verified both `setuptools==77.0.3` and modern `setuptools` sdist/wheel builds.
- **Annoy worker provenance (`C02`)**: Updated `find_sm_nn`, `find_mm_nn`, and `run_scslide_workflow` so `NeighborResult.params["workers_effective"]` and `WorkflowResult.inference_summary["workers_effective"]` report the actual resolved worker count forwarded to `AnnoyIndex.build(..., n_jobs=eff_workers)` rather than hardcoding `1`, while explicitly separating `build_workers_effective` and `query_workers_effective` (`1` for Annoy's serial query loop) and recording `exceeds_available_cpus`.
- **Missing permutation gene accounting (`C04`)**: Added `emp_n_finite_perms`, `emp_n_missing_perms`, `emp_missing_perm_rate`, and `missing_gene_policy` provenance to `run_unified_permutation_inference` and `calibrate_traj_de_donor_permutation` alongside `emp_n_valid_perms`.
- **Repeated-visit discordant subject responses (`C05`)**: Extended subject-level response consistency validation in `run_confirmatory_oof_traj_de` so changing within-subject responses across longitudinal visits are rejected even when `n_phenotype_permutations=0`.
- **Legacy `confirmatory_*` workflow aliases (`C06`)**: Emitted explicit migration `UserWarning`s when `de_inference_mode` uses legacy `confirmatory_*` names, recorded `de_inference_mode_effective` (`exploratory_*`), `legacy_mode_alias_used=True`, and `confirmatory_calibration_established=False`, and clarified diagnostic warning text in `calibrate_traj_de_donor_permutation`.
- **Out-of-checkout & sdist test portability (`C07`)**: Bundled `tests/fixtures/lmc_contract.json` inside `tests/` and configured an explicit `MANIFEST.in` distribution whitelist so unpacked `sdist` archives and copied `tests/` execute cleanly outside the Git repository without referencing `campaign/`.

### Added
- Explicit `annoy = ["annoy>=1.17"]` optional extra in `pyproject.toml` (separate from `[ann] = ["pynndescent>=0.5", "umap-learn>=0.5"]`) and actionable `ImportError` installation guidance.
- Portable deterministic synthetic demo generator `scslide.build_synthetic_cohort_fixture` (`synthetic_demo_only=True`, supporting both `AnnData` and core-only NumPy/SciPy modes) plus `examples/r_to_python_migration_quickstart.py` and `examples/export_seurat_for_scslide_py.R`.
- Release engineering documentation (`docs/RELEASE_SCOPE.md`, `docs/SUPPORTED_ENVIRONMENTS.md`, `docs/R_TO_PY_MIGRATION.md`, `docs/MAINTENANCE_AND_ROLLBACK.md`), pinned verification constraints (`constraints/`), `NOTICE`, `CITATION.cff`, and redaction-aware `.github/ISSUE_TEMPLATE/bug_report.md`.

## [0.3.2] - 2026-11-16 (`scslide-py-0.3.2-1219e90833d6`, Frozen Baseline)

### Fixed
- Forwarded resolved `n_jobs` worker budget to `AnnoyIndex.build(annoy_n_trees, n_jobs=eff_workers)` and added nested conventional Linux cgroup v1/v2 ancestor quota detection in `resolve_effective_workers`.
- Counted missing/non-finite null permutation draws as conservative exceedances under `missing_gene_policy="conservative_one"` (`p = 1.0` when all draws are missing).
- Rejected changing within-subject response values during subject phenotype permutations (`n_phenotype_permutations > 0`).
- Scoped OOF/count-splitting and permutation APIs/documentation as `exploratory_*` (`shared_donor_latent_fdr_calibrated=False`).

## [0.3.1] - 2026-11-15 (`scslide-py-0.3.1-8c9078614dcb`)

### Added
- `resolve_effective_workers` OS CPU affinity (`sched_getaffinity`) and root cgroup quota resolution (`n_jobs=1` default).
- Gene-aligned exploratory subject OOF phenotype-null and max-F diagnostic columns in `run_confirmatory_oof_traj_de`.

## [0.3.0] - 2026-11-14 (`scslide-py-0.3.0-5ea052de1d88`, Frozen Historical Baseline)

### Added
- Seurat `FastDenseRowScale` upper-only residual clipping (`scale_max=10.0`), `SampleLevelObject.subset_samples(..., recompute_normalization=False)`, subject-vs-draw auditing (`resolve_subject_mapping`, `stratified_subject_kfold`), sparse `binomial_thin_counts`, explicit UMAP backend contract (`allow_fallback=False` default), and open backed HDF5/Zarr handle validation.

## [0.2.0] - 2026-11-13

### Added
- Native Python implementation of all 19 upstream `scSLIDE` / `Seurat v6` capabilities (`F01`–`F19`), non-pickle `PLSModel` `.npz` persistence, rectangular neighbor storage in `AnnData.obsm`, and publication plotting helpers with `.csv` source-data sidecars.

## [0.1.1] - 2026-11-13

### Added
- Initial sample-level LMC matrix, Pearson residual operator, named-feature PLS alignment, and `scslide-calibrate` synthetic CLI.
